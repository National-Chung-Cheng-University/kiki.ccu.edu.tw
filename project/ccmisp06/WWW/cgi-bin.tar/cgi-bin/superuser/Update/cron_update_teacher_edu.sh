#!/bin/sh

cd /ultra2/project/ccmisp06/WWW/cgi-bin/superuser/Update/
/usr/local/bin/php  Update_teacher_edu.php
