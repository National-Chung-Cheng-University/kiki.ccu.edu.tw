<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<?PHP

//////////////////////////////////////////////////////////////////////////////////////////
/////  Student_Log_Stat.php
/////  學生LOG紀錄檔分析 - 使用版本分析
/////  顯示 LOG 紀錄檔中，學生使用傳統入口/SSO/行動版/英文版等版本登入之人次與比例分析
/////  Updates:
/////    2014/10/03 Created by Nidalap :D~

set_time_limit(60*6);
$now = time();

require_once "../../library/Reference.php";
require_once $LIBRARY_PATH . "Error_Message.php";
require_once $LIBRARY_PATH . "Common_Utility.php";
require_once $LIBRARY_PATH . "System_Settings.php";
require_once $LIBRARY_PATH . "Dept.php";
require_once $LIBRARY_PATH . "Course.php";
require_once $LIBRARY_PATH . "Student.php";

echo Include_jQuery(1);
$DEBUG = 0;

$log_file = $DATA_PATH . "Student.log";
$handle = fopen($log_file, "r");

$types = array(
  array("type" =>"trad",	"action" => "Login",		"ctype" => "傳統入口"),
  array("type" =>"SSO",		"action" => "Login_SSO",	"ctype" => "SSO"),
  array("type" =>"mobile",	"action" => "LoginM",		"ctype" => "行動版"),
  array("type" =>"eng",		"action" => "LoginE",		"ctype" => "英文版")
);

$i = 0;

while( $line = fgets($handle) ) {
  if( ($DEBUG)==1 and ($i>=300000) )  break;
  list($action, $time, $ip, $id, $junk) = explode(" : ", $line);
  list($time, $junk) = explode(" ", $time);
  list($month, $day, $year) = explode("/", $time);
  $year_month = $year . "-" . $month;
  if( $i++ == 0 )  $day_first = $time;
  
  foreach ($types as $type) {
    if( rtrim($action) == $type["action"] )   $stat[$year_month][$type["type"]]["count"]++;
  }
}
$day_last = $time; 

foreach( $stat as $year_month => $stat_m ) {
  foreach( $types as $type ) {
    if( !array_key_exists($type["type"], $stat_m) ) {
	  $stat[$year_month][$type["type"]]["count"] = 0;
	}
	$total[$year_month] += $stat[$year_month][$type["type"]]["count"];
  }
  foreach( $types as $type ) {
    $stat[$year_month][$type["type"]]["ratio"] = round(($stat[$year_month][$type["type"]]["count"] / $total[$year_month])*100,1);
  }
}

//print_r($stat);

echo "
  統計區間：[$day_first ~ $day_last]
  <P>
  <TABLE border=1>
    <TR><TH>年月</TH><TH>版本</TH><TH>人次</TH><TH>比例</TH></TR>
";

foreach( $stat as $year_month => $stat_m ) {
  echo "<TR><TD rowspan=" . count($types) . ">$year_month</TD>";
  $i=0;
  foreach( $types as $type ) {
//  foreach( $stat_m as $type=>$count ) {
    echo "<TD>" . $type["ctype"] . "</TD><TD>" . $stat[$year_month][$type["type"]]["count"] . "</TD><TD>" . $stat[$year_month][$type["type"]]["ratio"] . "%</TD></TR>\n";
  }
  
  echo "</TR>\n";
}
echo "  
  </TABLE>
  <HR>
";


echo '<DIV id="container">cc</DIV>';
echo Create_Graph(); 

$now = time() - $now;
echo "<P>執行時間： $now 秒<P>";




///////////////////////////////////////////////////////////////////////////////////////////////////
function Create_Graph()
{
  global $day_first, $day_last, $stat, $types;
  $x_axis = NULL;
  $data = NULL;
 
  foreach( $stat as $year_month => $stat_m ) {
    if( $x_axis != NULL )  $x_axis .= ", ";
	$x_axis = $x_axis . "'" . $year_month . "' ";
    $i=0;
    foreach( $types as $type ) {
	  if( array_key_exists($type["type"], $data) ) {
	    $data[$type["type"]] .= ", ";
	  }
	  $data[$type["type"]] .= $stat[$year_month][$type["type"]]["ratio"];
	  $type_c[$type["type"]] = $type["ctype"];
    }
  }
  $series = "[";
  foreach ($data as $type=>$d) {
    $data[$type] = "[" . $d . "]";
	$series .= "{ name: '" . $type_c[$type] . "', data: [ $d ] }, ";
	
	//[{ name: 'Tokyo', data: [7.0, 6.9, 9.5, 14.5, 18.2, 21.5, 25.2, 26.5, 23.3, 18.3, 13.9, 9.6] },
  }
  $series .= "]";

  if( $DEBUG ) {
    echo "&nbsp;<HR>\n";  echo "&nbsp;<HR>\n";echo "&nbsp;<HR>\n";echo "&nbsp;<HR>\n";echo "&nbsp;<HR>\n";echo "&nbsp;<HR>\n";
    echo "stat = ";
    print_r($stat);
    echo "<HR>\n";
    echo "data = ";
    print_r($data);
    echo "<HR>\n";
    echo "x_axis = ";
    print_r($x_axis);
    echo "<HR>\n";
    echo "series = ";
    print_r($series); 
  }
  
  $html =  "
  <STYLE>
    #container {
      position: absolute;
      left: 300px;
      top: 0px;
	}
  </STYLE>
  <SCRIPT language='JavaScript'>
  $(function () {
    $('#container').highcharts({
        title: {
            text: '選課系統使用版本統計',
            x: -20 //center
        },
        subtitle: {
            text: '統計區間：$day_first ~ $day_last',
            x: -20
        },
        xAxis: {
            categories: [ $x_axis ]
        },
        yAxis: {
            title: {
                text: '比例(%)'
            },
            plotLines: [{
                value: 0,
                width: 1,
                color: '#808080'
            }]
        },
        tooltip: {
            valueSuffix: '%'
        },
        legend: {
            layout: 'vertical',
            align: 'right',
            verticalAlign: 'middle',
            borderWidth: 0
        },
        series: $series
    });
  });

  </SCRIPT>
  ";
  
  return $html;
}


?>