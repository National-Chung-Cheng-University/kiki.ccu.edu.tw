<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<?PHP

//////////////////////////////////////////////////////////////////////////////////////////
/////  Student_Log_Stat.php
/////  學生LOG紀錄檔分析 - 使用版本分析
/////  顯示 LOG 紀錄檔中，學生使用傳統入口/SSO/行動版/英文版等版本登入之人次與比例分析
/////  Updates:
/////   2014/10/03 Created by Nidalap :D~
/////	2016/06/20 新增開始與結束日期輸入頁面（此頁） by Nidalap :D~

set_time_limit(60*6);
$now = time();

require_once "../../library/Reference.php";
require_once $LIBRARY_PATH . "Error_Message.php";
require_once $LIBRARY_PATH . "Common_Utility.php";
require_once $LIBRARY_PATH . "System_Settings.php";
require_once $LIBRARY_PATH . "Dept.php";
require_once $LIBRARY_PATH . "Course.php";
require_once $LIBRARY_PATH . "Student.php";

echo Include_jQuery(1);
$DEBUG = 0;

$log_file = $DATA_PATH . "Student.log";
$handle = fopen($log_file, "r");
$log_file2 = $DATA_PATH . "Student.old.log";
$handle2 = fopen($log_file2, "r");

$types = array(
  array("type" =>"trad",	"action" => "Login",		"ctype" => "傳統入口"),
  array("type" =>"SSO",		"action" => "Login_SSO",	"ctype" => "SSO"),
  array("type" =>"mobile",	"action" => "LoginM",		"ctype" => "行動版"),
  array("type" =>"eng",		"action" => "LoginE",		"ctype" => "英文版")
);

$i = 0;

$line_start = fgets($handle2);
$line_end	= exec("tail -n 1 $log_file");

$temp = preg_split("/ : /", $line_start);
$temp = preg_split("/ /", $temp[1]);
$day_start = $temp[0];

$temp = preg_split("/ : /", $line_end);
$temp = preg_split("/ /", $temp[1]);
$day_end = $temp[0];

echo "
  <FORM action='Student_Log_Stat02.php'>
  <CENTER>
    <H1>學生LOG紀錄檔分析 - 使用版本分析</H1>
	<HR>
	請輸入統計區間：
	<P>
	開始日：<INPUT name='day_start' value='$day_start'>
	<BR>
	結束日：<INPUT name='day_end' value='$day_end'>
	<BR>
    <INPUT type='submit' value='開始統計'>
  </CENTER>
  </FORM>
";


?>