
<FORM action='Course_Data.php' method='POST'>
  <INPUT name='query[]' value='4105100_01'><BR>
  <INPUT name='query[]' value='4105106_01'><BR>
  <INPUT name='query[]' value='4105310_01'><BR>
  <INPUT name='query[]' value=''><BR>
  <P>
  <INPUT name='year' value='104'>
  <P>
  <INPUT name='term' value='1'>
  <P>
  <INPUT type='submit' value='submit'>
</FORM>

