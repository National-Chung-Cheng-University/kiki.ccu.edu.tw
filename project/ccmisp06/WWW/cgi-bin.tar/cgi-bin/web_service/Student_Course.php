<?PHP

require_once "../library/Reference.php";
require_once $LIBRARY_PATH . "Database.php";
require_once $LIBRARY_PATH . "Common_Utility.php";
require_once $LIBRARY_PATH . "Course.php";
require_once $LIBRARY_PATH . "Classroom.php";
require_once $LIBRARY_PATH . "Dept.php";
require_once $LIBRARY_PATH . "Student.php";
require_once $LIBRARY_PATH . "Student_Course.php";
require_once $LIBRARY_PATH . "Password.php";
require_once $LIBRARY_PATH . "Teacher.php";

$system_settings = Get_System_State();

$id			= quotes($_REQUEST['id']);
$password	= quotes($_REQUEST['password']);

$salt = Read_Crypt_Salt($id);
$password = my_Crypt($password, $salt);


//echo "$id, $password<br>\n";
//echo '<meta http-equiv="Content-Type" content="text/html; charset=utf-8">';
Check_Password($id, $password);
$courses = Course_of_Student($id);
$all_teachers = Read_All_Teacher();

foreach ($courses as $cour) {
  $tmp = Read_Course($cour["dept"], $cour["id"], $cour["group"]);
  $classroom = Read_Classroom($tmp["classroom"]);
  $dept = Read_Dept($tmp['dept']);
  
  //print_r($classroom);
  
  $course['id']			= $tmp['id'];
  $course['cname']		= $tmp['cname'];
  $course['dept']		= $dept['cname2'];
  $course['group']		= $cour["group"];
  $i=0;
  foreach( $tmp['time'] as $time ) {
	$tmp['time'][$i]['time'] = $TIME_TIME[$time['time']];
	$i++;
  }
  $course['time']		= $tmp['time'];
  $course['classroom']	= $classroom['cname'];
  $course['teacher']	= Format_Teacher_String($tmp['teacher']);
  
  $cou[] = $course;
//  print_r($tmp);
  //print_r($course);
}

echo '<meta http-equiv="Content-Type" content="text/html; charset=utf-8">';
print_r($cou);
echo "<HR>\n";

$return_str = json_encode($cou);

//echo "\n\n<HR>\n\n";
echo $return_str;
  
?>