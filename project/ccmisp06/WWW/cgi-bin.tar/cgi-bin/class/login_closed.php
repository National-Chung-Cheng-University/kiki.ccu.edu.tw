<HTML>
<!script type="text/javascript" src="acpwd.js"></script>
<?PHP
  include "../library/Reference.php";
  include $LIBRARY_PATH . "Error_Message.php";

  $system_settings = Get_System_State();
?>

 <HEAD>
   <meta http-equiv="Content-Type" content="text/html; charset=big5">
   <TITLE>LOGIN</TITLE>
 </HEAD>
  <BODY>

  <FONT size=2>
  <CENTER>
  �ثe��Ҩt��������
 </BODY>
</HTML>